# ckeditor-bootstrap-tabs
A plugin for CKEditor that allows for the user to insert and edit a specified number of Bootstrap tabs.

![ckeditor-bootstrap-tabs screenshot](#)

## Demo
Check out the demo at #

## Installation
1. Download the zip file.
- Extract the contents to your CKEditor plugins directory: `/path/to/ckeditor/plugins/bootstrapTabs`.
